//
//  GlobleVariables.swift
//  JSONParsing
//
//  Created by haider ali on 28/01/2020.
//  Copyright © 2020 haider ali. All rights reserved.
//

import Foundation



var responseData: Object!

