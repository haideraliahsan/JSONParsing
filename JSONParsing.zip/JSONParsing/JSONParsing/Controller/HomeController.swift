//
//  ViewController.swift
//  JSONParsing
//
//  Created by haider ali on 27/01/2020.
//  Copyright © 2020 haider ali. All rights reserved.
//

import UIKit
import SDWebImage



class HomeController: UIViewController{
    
    
    let cellId = "countryId"
    var adapter: [Carousel] = []
    
    @IBOutlet weak var countriesTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        countriesTableView.delegate = self
        countriesTableView.dataSource = self
        
        
        
        ApiService.postRequest(onsuccess: {
            DispatchQueue.main.sync(execute: {
                print(responseData.content.carousel)
                self.adapter = responseData.content.carousel + responseData.content.dashboard_items
                self.countriesTableView.reloadData()
               })
        })
        
        
        
//        ApiService.fetchCountries {
//            // got data from the server
//            DispatchQueue.main.sync(execute: {
//                self.countriesTableView.reloadData()
//               })
//            
//        }
        
        
        
        
        
        
        
        
        
        
    }


}
extension HomeController: UITableViewDataSource, UITableViewDelegate {
   
    
  
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return adapter.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = countriesTableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as! CountryCell

        cell.flagImageView.imageFromURL(urlString: adapter[indexPath.row].imagePath)
        cell.name.text = adapter[indexPath.row].text
        cell.capital.text = adapter[indexPath.row].offerId
        cell.region.text = adapter[indexPath.row].type
  
        return cell
        
    }
    
    
}

