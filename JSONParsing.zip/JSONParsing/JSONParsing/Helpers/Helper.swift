
//
//  He.swift
//  JSONParsing
//
//  Created by haider ali on 28/01/2020.
//  Copyright © 2020 haider ali. All rights reserved.
//

import UIKit



class RoundShadowView: UIView {
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        layer.borderWidth = 1.0
        layer.borderColor = UIColor.clear.cgColor
        layer.cornerRadius = 12
        clipsToBounds = true
         layer.masksToBounds = false
         layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 0.5
         layer.shadowOffset = .zero
         layer.shadowRadius = 8
//         layer.shouldRasterize = true
        layer.rasterizationScale = 1.0
        
    }
}



class CircularImageView: UIImageView {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.shadowRadius = 5;
               self.layer.shadowOpacity = 0.5;
               self.layer.cornerRadius = self.frame.height / 2
               self.layer.borderWidth = 2
               self.layer.borderColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0)
        
               self.layer.masksToBounds = true;
               
        
    }
    
    
    
}
