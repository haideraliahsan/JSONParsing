//
//  Constants.swift
//  JSONParsing
//
//  Created by haider ali on 27/01/2020.
//  Copyright © 2020 haider ali. All rights reserved.
//

import Foundation

let WEB_LINK = "https://qa-dot-vigilant-armor-249803.appspot.com/dashboard/home"
let  TOKEN = "eyJhbGciOiJIUzUxMiIsImlhdCI6MTU4MDE4NjAwNiwiZXhwIjoxNTgwNzg2MDA2fQ.eyJpZCI6Ijg4ODg4ODEyMzQifQ.8QXfk63_9qemHkLitxw3FFYxevpcY47nQ2AUGdpPh1YMwCtOCI3UnEnX2EzIPh3lVyqQLu3wUuK8kHZnFSxx6w"
let PHONE = "8888881234"

