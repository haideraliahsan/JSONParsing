//
//  Countries.swift
//  JSONParsing
//
//  Created by haider ali on 27/01/2020.
//  Copyright © 2020 haider ali. All rights reserved.
//

import Foundation


struct Object: Codable {
    var content: Content
    var status: String
    
    init(json: [String: Any]) {
        content = json["content"] as! Content
        status = json["status"] as! String
    }
}


struct Content: Codable {
    var carousel: [Carousel]
    var dashboard_items: [Carousel]
    var notifications: [String]
}


struct Carousel: Codable {
    var imagePath: String
    var offerId: String
    var text:String
    var type: String
}

