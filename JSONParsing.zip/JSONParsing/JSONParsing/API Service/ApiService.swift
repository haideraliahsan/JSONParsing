//
//  ApiService.swift
//  JSONParsing
//
//  Created by haider ali on 27/01/2020.
//  Copyright © 2020 haider ali. All rights reserved.
//

import Foundation
import SwiftyJSON

class ApiService {
    static func fetchCountries(onsuccess: @escaping () -> ()){
        let url = URL(string: WEB_LINK)
        URLSession.shared.dataTask(with: url!) {(data, response, error) in

            if error != nil || data == nil {
                print("Client error!")
                return
            }

            guard let response = response as? HTTPURLResponse, (200...299).contains(response.statusCode) else {
                print("Server error!")
                return
            }

            guard let mime = response.mimeType, mime == "application/json" else {
                print("Wrong MIME type!")
                return
            }

            do {
                let countries = try JSONDecoder().decode(Content.self, from: data!)
                
//                for country in countries {
//
//                    allCountries.append(country)
//                }
                onsuccess()
                
            }catch {
                print("We got an error")
            }
        }.resume()
        
    }
    
    static func postRequest (onsuccess: @escaping () -> ()) {
        
        let session = URLSession.shared
        let request = NSMutableURLRequest(url: NSURL(string: WEB_LINK)! as URL)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        var params :[String: Any]?
        params = [
            "phone": PHONE,
            "token": TOKEN,
        ]
        do{
            request.httpBody = try JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())
            let task = session.dataTask(with: request as URLRequest , completionHandler: {(data, response, error) in
                if let response = response {
                    let nsHTTPResponse = response as! HTTPURLResponse
                    let statusCode = nsHTTPResponse.statusCode
                    print ("status code = \(statusCode)")
                }
                
                if error != nil || data == nil {
                    print("Client error!")
                    return
                }
                if let error = error {
                    print ("\(error)")
                }
                if let data = data {
   
                    
                    
                   do {
                    
                    let content = try JSONDecoder().decode(Object.self, from: data)
                    responseData = content


                        onsuccess()
                    }catch {
                        print("We got an error")
                    }
                }
                }).resume()
            
        }catch _ {
            print ("Oops something happened buddy")
        }
    }
}
